const express = require('express');
const bodyParser = require('body-parser');
const twilio =require('twilio');
const app = express();
const port = process.env.PORT || 3000;
const accountSid = 'AC3b3f728182299ff3935d782f373f7719';
const authToken ='1a391c7ee297dd10c40ccb14a4c45a60';
const client = twilio (accountSid, authToken);
app.use(bodyParser.urlencoded({extended: false

  app.post('/send-sms', (req, res) => {
  
  const { to, body} req.body;
  
  client.messages.create({
  body: body,
  to: to,
  from: '+19135131093'
  })
  .then(() => {
  res.send('SMS sent successfully!');
  })
  .catch((err) => {
  console.error(err);
  res.status(500).send('Error sending SMS');
  });
  });
  app.listen(port, () => {
  console.log("Server listening on port ${port)
  })
