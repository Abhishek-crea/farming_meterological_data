# Krishi
<a href="https://royishan.github.io/Krishi.github.io/index.html"> Click Here for Website</a>
<br>
Krishi (All You Need for Agronomy) is a website particularly for the Indian Farmers to provide all information in one portal.
